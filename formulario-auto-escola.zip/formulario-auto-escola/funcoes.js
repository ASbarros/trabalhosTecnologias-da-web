var pontuacao = 0,
    opc;

function verifica() {
    if (pontuacao <= 3) {
        let form = document.getElementsByClassName('formulario');
        let p = form[0];
        for (let i = 0; i < p.length; i++) {
            let input = p[i];
            if ((input.id == input.value) && (input.value == opc)) {
                pontuacao++;
                carregar('formulario' + (pontuacao + 1) + '.html');
            }
        }
        pontos();
    }
}

function marcado(_opc) {
    opc = _opc;
}

function pontos() {
    if (pontuacao > 0) {
        let div = document.getElementById('pontos');
        div.innerHTML = 'Pontuação: ' + pontuacao;
        //document.body.appendChild(div);
    }
}